const express = require('express')

module.exports = function(server) {

  // API routes
  const router = express.Router()
  server.use('/api', router)

  //Rotas da api
  const pedidoService = require('../api/pedido/pedidoService')
  pedidoService.register(router, '/pedido')

  const pedidoListaService = require('../api/pedido/pedidoListaService')
  router.route('/pedido/lista').get(pedidoListaService.getPedidos)

  const clienteService = require('../api/cliente/clienteService')
  clienteService.register(router, '/cliente')

  const clienteListaService = require('../api/cliente/clienteListaService')
  router.route('/cliente/byName').get(clienteListaService.getByName)

  const estoqueService = require('../api/estoque/estoqueService')
  estoqueService.register(router, '/estoque')

  const prestadorService = require('../api/prestador/prestadorService')
  prestadorService.register(router, '/prestador')

  const servicoService = require('../api/servico/servicoService')
  servicoService.register(router, '/servico')

  const servicoListaService = require('../api/servico/servicoListaService')
  router.route('/servico/getServicos').get(servicoListaService.getServicos)
  router.route('/servico/getPecas').get(servicoListaService.getPecas)
  router.route('/servico/getValor').get(servicoListaService.getValor)
}
