module.exports = {
  SECRET: "peddidoapp",
  EXPIRES_IN: "7d"
};
