angular.module('pedidosApp', [
  'ui.router',
  'ngAnimate',
  'toastr'
])
